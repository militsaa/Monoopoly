#include <iostream>
#include "GameManager.h"
//#include "Vector.h"

int main() {
	GameManager& gm = GameManager::getInstance();
	gm.play();
}

//impl cardDeck - vector<card> - add all //
//check for bankupt rulls and impl//
//build functionality
//moving on board with die
// trade
// 
//start commands 


//have limited cottages and castles
//doesnt have bank

//func message