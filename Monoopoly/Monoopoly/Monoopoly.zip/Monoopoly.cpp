#include <iostream>

int main() {
    std::cout << "Hello World!\n";
}

//impl cardDeck - vector<card> - add all //
//check for bankupt rulls and impl//
//build functionality
//moving on board with die
//start commands 


//have limited cottages and castles
//doesnt have bank