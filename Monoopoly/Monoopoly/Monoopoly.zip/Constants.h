#pragma once

const int MONOPOLY_FIELDS_CNT = 40;
const int GO_PRICE = 200;
const double COTTAGE_FACTOR = 0.15; 
const double CASTLE_FACTOR = 0.5;