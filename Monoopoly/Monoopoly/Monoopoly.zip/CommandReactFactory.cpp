#include "CommandReactFactory.h"
#include "GameManager.h"

void CommandReactFactory::action(const String& command)
{
	GameManager& gm = GameManager::getInstance();
	if (command == "ROLL")
	{
		gm.rollTheDiesAndMove();
	}
}
