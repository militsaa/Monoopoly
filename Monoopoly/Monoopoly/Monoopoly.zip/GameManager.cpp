#include "GameManager.h"

//void GameManager::buildCottage(int index)
//{
//	/*if (board.getFields()[index]->getType() == FieldType::PROPERTY &&)
//	{
//
//	}*/
//}

GameManager::GameManager()
{
}
