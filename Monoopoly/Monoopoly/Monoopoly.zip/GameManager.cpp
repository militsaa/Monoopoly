#include "GameManager.h"

//void GameManager::buildCottage(int index)
//{
//	/*if (board.getFields()[index]->getType() == FieldType::PROPERTY &&)
//	{
//
//	}*/
//}

GameManager::GameManager()
{
    //TO DO?
}

bool GameManager::canBuild(int player, int field) const
{
    int curr;
    for (int i = -2; i <= 2; i++)
    {
        curr = player + i;
      /*  if (curr < 0) curr += FIELDS_COUNT;
        {

        }*/

    }
}

GameManager& GameManager::getInstance()
{
    static GameManager instance;
    return instance;
}

Vector<Player*> GameManager::getPlayers() const
{
    return players;
}

Vector<Field*> GameManager::getFields() const
{
    return board.getFields();
}

void GameManager::buildCottage(int index)
{
    if (!cottageLeft)
    {
        std::cout << "All cottages are taken!";
    }
   
}

