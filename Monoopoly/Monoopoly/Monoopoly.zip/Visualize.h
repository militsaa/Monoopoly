#pragma once
#include "GameManager.h";

void printSquareBoard(const Vector<Field*>& fields);
