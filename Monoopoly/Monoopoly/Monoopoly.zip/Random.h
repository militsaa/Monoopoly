#pragma once

int randomNumberGenerator(int size);

int dieGenerator(int size);