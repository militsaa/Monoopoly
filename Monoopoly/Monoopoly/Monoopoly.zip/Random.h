#pragma once

int randomNumberGenerator(int size);