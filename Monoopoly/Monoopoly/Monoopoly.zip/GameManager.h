#pragma once
#include "Vector.h"
#include "Player.h"
#include "Board.h"

class GameManager {
	Vector<Player*> players;
	Board& board = Board::getInstance();
	GameManager();
	int cottageLeft = 32;
	int castlesLeft = 12;
	bool canBuild(int player, int field)const;
public:
	GameManager(const GameManager& other) = delete;
	GameManager& operator=(const GameManager& other) = delete;
	static GameManager& getInstance();
	Vector<Player*> getPlayers() const;
	Vector<Field*> getFields() const;
	void buildCottage();
	void buildCastle();
	//here estimate how many to pay for each prop when on it
};