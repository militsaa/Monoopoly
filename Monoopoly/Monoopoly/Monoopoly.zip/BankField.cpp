#include "BankField.h"

BankField::BankField(String name, FieldType type, int am) : Field(name, type), amount(am) {}
